from django.apps import AppConfig


class PayzantConfig(AppConfig):
    name = 'payzant'
